#include "apc.h"

void multiplication(node *tail1, node *tail2, node **headR, node **tailR)
{
    long long num1 = 0;
    long long num2 = 0;
    long long result;

    /* Move to head of first list */
    while(tail1->prev)
        tail1 = tail1->prev;

    /* Move to head of second list */
    while(tail2->prev)
        tail2 = tail2->prev;

    /* Convert first list into number */
    while(tail1)
    {
        num1 = num1 * 10 + tail1->data;
        tail1 = tail1->next;
    }

    /* Convert second list into number */
    while(tail2)
    {
        num2 = num2 * 10 + tail2->data;
        tail2 = tail2->next;
    }

    result = num1 * num2;

    if(result == 0)
    {
        insert_last(headR, tailR, 0);
        return;
    }

    while(result)
    {
        insert_first(headR, tailR, result % 10);
        result /= 10;
    }
}