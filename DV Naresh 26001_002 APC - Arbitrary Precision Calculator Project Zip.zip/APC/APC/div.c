#include "apc.h"

void division(node *head1, node *head2, node **headR, node **tailR)
{
    long long num1 = 0, num2 = 0;

    while (head1)
    {
        num1 = num1 * 10 + head1->data;
        head1 = head1->next;
    }

    while (head2)
    {
        num2 = num2 * 10 + head2->data;
        head2 = head2->next;
    }

    if (num2 == 0)
    {
        printf("Division by zero not possible\n");
        return;
    }

    long long result = num1 / num2;

    if (result == 0)
    {
        insert_last(headR, tailR, 0);
        return;
    }

    while (result)
    {
        insert_first(headR, tailR, result % 10);
        result /= 10;
    }
}