#include "apc.h"

// Function definitions

int cla_validation(int argc, char *argv[])
{
    if (argc != 4)
    {
        return FAILURE;
    }

    return SUCCESS;
}

int insert_first(node **head, node **tail, int data)
{
    node *new = malloc(sizeof(node));

    if (new == NULL)
    {
        return FAILURE;
    }

    new->data = data;
    new->prev = NULL;
    new->next = *head;

    if (*head != NULL)
    {
        (*head)->prev = new;
    }
    else
    {
        *tail = new;
    }

    *head = new;

    return SUCCESS;
}

int insert_last(node **head, node **tail, int data)
{
    node *new = malloc(sizeof(node));

    if (new == NULL)
    {
        return FAILURE;
    }

    new->data = data;
    new->next = NULL;
    new->prev = *tail;

    if (*tail != NULL)
    {
        (*tail)->next = new;
    }
    else
    {
        *head = new;
    }

    *tail = new;

    return SUCCESS;
}

void create_list(char *opr, node **head, node **tail)
{
    while (*opr)
    {
        insert_last(head, tail, *opr - '0');
        opr++;
    }
}

int delete_list(node **head, node **tail)
{
    node *temp;

    while (*head)
    {
        temp = *head;
        *head = (*head)->next;
        free(temp);
    }

    *tail = NULL;

    return SUCCESS;
}

void print_list(node *head)
{
    if (head == NULL)
    {
        printf("0\n");
        return;
    }

    while (head)
    {
        printf("%d", head->data);
        head = head->next;
    }

    printf("\n");
}

int list_len(node *head)
{
    int count = 0;

    while (head)
    {
        count++;
        head = head->next;
    }

    return count;
}

int compare_list(node *head1, node *head2)
{
    int len1 = list_len(head1);
    int len2 = list_len(head2);

    if (len1 > len2)
    {
        return OPERAND1;
    }

    if (len2 > len1)
    {
        return OPERAND2;
    }

    while (head1 && head2)
    {
        if (head1->data > head2->data)
        {
            return OPERAND1;
        }

        if (head2->data > head1->data)
        {
            return OPERAND2;
        }

        head1 = head1->next;
        head2 = head2->next;
    }

    return SAME;
}

void remove_pre_zeros(node **head)
{
    node *temp;

    while (*head && (*head)->data == 0 && (*head)->next)
    {
        temp = *head;
        *head = (*head)->next;
        (*head)->prev = NULL;
        free(temp);
    }
}