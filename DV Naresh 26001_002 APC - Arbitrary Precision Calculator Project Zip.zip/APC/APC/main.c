/*

NAME OF THE PROJECT : Arbitrary Precision Calculator
NAME OF THE STUDENT : DV Naresh
REGISTRATION NUMBER : 26001_002
DATE OF SUBMISSION : 30/06/2026
*/


#include "apc.h"

int main(int argc, char *argv[])
{
    node *head1 = NULL, *tail1 = NULL;
    node *head2 = NULL, *tail2 = NULL;
    node *headR = NULL, *tailR = NULL;

    int sign1 = 0, sign2 = 0;
    int result_sign = 0;
    int cmp;

    char *op1, *op2;

    // Validation
    if (cla_validation(argc, argv) == FAILURE)
    {
        printf("ERROR : Invalid Command Line Arguments\n");
        printf("Usage : ./a.out <Operand1> <Operator> <Operand2>\n");
        return FAILURE;
    }

    printf("Operand 1 : %s\n", argv[1]);
    printf("Operator  : %c\n", argv[2][0]);
    printf("Operand 2 : %s\n", argv[3]);

    op1 = argv[1];
    op2 = argv[3];

    if(op1[0] == '-')
    {
        sign1 = 1;
        op1++;
    }

    if(op2[0] == '-')
    {
        sign2 = 1;
        op2++;
    }

    // Create 2 lists of operands
    create_list(op1, &head1, &tail1);
    create_list(op2, &head2, &tail2);

    // Remove pre zeros
    remove_pre_zeros(&head1);
    remove_pre_zeros(&head2);

    switch(argv[2][0])
    {
        case '+':

            if(sign1 == sign2)
            {
                addition(tail1, tail2, &headR, &tailR);

                if(sign1 == 1)
                    result_sign = 1;
            }
            else
            {
                cmp = compare_list(head1, head2);

                if(cmp == OPERAND1)
                {
                    subtraction(tail1, tail2, &headR, &tailR);

                    if(sign1 == 1)
                        result_sign = 1;
                }
                else if(cmp == OPERAND2)
                {
                    subtraction(tail2, tail1, &headR, &tailR);

                    if(sign2 == 1)
                        result_sign = 1;
                }
                else
                {
                    insert_last(&headR, &tailR, 0);
                }
            }

            break;

        case '-':

            if(sign1 == 0 && sign2 == 0)
            {
                cmp = compare_list(head1, head2);

                if(cmp == OPERAND1)
                {
                    subtraction(tail1, tail2, &headR, &tailR);
                }
                else if(cmp == OPERAND2)
                {
                    subtraction(tail2, tail1, &headR, &tailR);
                    result_sign = 1;
                }
                else
                {
                    insert_last(&headR, &tailR, 0);
                }
            }
            else if(sign1 == 0 && sign2 == 1)
            {
                addition(tail1, tail2, &headR, &tailR);
            }
            else if(sign1 == 1 && sign2 == 0)
            {
                addition(tail1, tail2, &headR, &tailR);
                result_sign = 1;
            }
            else
            {
                cmp = compare_list(head1, head2);

                if(cmp == OPERAND1)
                {
                    subtraction(tail1, tail2, &headR, &tailR);
                    result_sign = 1;
                }
                else if(cmp == OPERAND2)
                {
                    subtraction(tail2, tail1, &headR, &tailR);
                }
                else
                {
                    insert_last(&headR, &tailR, 0);
                }
            }

            break;

        case 'x':
        case 'X':

            multiplication(tail1, tail2, &headR, &tailR);

            if(sign1 != sign2)
                result_sign = 1;

            break;

        case '/':

            division(head1, head2, &headR, &tailR);

            if(sign1 != sign2)
                result_sign = 1;

            break;

        default:
            printf("Invalid Operator\n");
            return FAILURE;
    }

    printf("Result    : ");

    if(result_sign)
        printf("-");

    print_list(headR);

    delete_list(&head1, &tail1);
    delete_list(&head2, &tail2);
    delete_list(&headR, &tailR);

    return SUCCESS;
}